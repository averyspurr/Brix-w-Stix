let bg;
let x = 0;
let y = 0;
let img;

function preload(){
	img = loadImage('assets/cheems.png');
}
function setup() {
  bg = loadImage("assets/stagebackground.png");
  loadImage(img, 0, 0);
  createCanvas(800, 800);
}

function keyPressed(){
	if(keyCode === UP_ARROW){
		y = y - 5;
	}
	
	if(keyCode === DOWN_ARROW){
		y = y + 5;
	}
	
	if(keyCode === LEFT_ARROW){
		x = x - 5;
	}
	
	if(keyCode === RIGHT_ARROW){
		x = x + 5;
	}
}


function draw() {
	
  background(bg);
  image(img, x, y);
  
}
